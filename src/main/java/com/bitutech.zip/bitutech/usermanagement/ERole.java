package com.bitutech.usermanagement;

public enum ERole {

	ROLE_USER,
    ROLE_ADMIN
    
}
