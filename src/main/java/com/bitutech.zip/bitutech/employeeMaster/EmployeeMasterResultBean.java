package com.bitutech.employeeMaster;

import java.util.List;

public class EmployeeMasterResultBean {
	public List<EmployeeMasterBean> employeeMasterList;
	
	public String message;
	public void setSuccess(boolean b) {
		// TODO Auto-generated method stub
		
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
