package com.bitutech.itemcategory;

public class ItemCategoryBean {
	
	private String unitMeasure;
	private String uomCategory;
	private String description;
	private String id;
	private String text;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getUnitMeasure() {
		return unitMeasure;
	}
	public void setUnitMeasure(String unitMeasure) {
		this.unitMeasure = unitMeasure;
	}
	public String getUomCategory() {
		return uomCategory;
	}
	public void setUomCategory(String uomCategory) {
		this.uomCategory = uomCategory;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
	
}
