package com.bitutech.boo;

public class BillOfOperationBean {
	
	private Integer booNo;
	private String bomRef;
	private String productName;
	private String date;
	


	public String getBomRef() {
		return bomRef;
	}
	public void setBomRef(String bomRef) {
		this.bomRef = bomRef;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Integer getBooNo() {
		return booNo;
	}
	public void setBooNo(Integer booNo) {
		this.booNo = booNo;
	}
	
	
	
}
