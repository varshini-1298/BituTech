package com.bitutech.itemMaster;

public class ItemMasterBean {
	
	private String itemType;
	private String itemName;
	private String itemDescription;
	private String itemCode;
	private String saleable;
	private String purchaseable;
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getSaleable() {
		return saleable;
	}
	public void setSaleable(String saleable) {
		this.saleable = saleable;
	}
	public String getPurchaseable() {
		return purchaseable;
	}
	public void setPurchaseable(String purchaseable) {
		this.purchaseable = purchaseable;
	}
	
	
}
