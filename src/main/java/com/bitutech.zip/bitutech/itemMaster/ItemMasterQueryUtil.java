package com.bitutech.itemMaster;

public class ItemMasterQueryUtil {

	public static final String INSERT_ITEM_MASTER = null;
	public static final String getItemList = "select form_code as territory,form_name as name,display_order as zipCode,module_code as addressOfCus,is_parent as organisationName from auth.form";

}
