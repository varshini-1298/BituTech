package com.bitutech.workorder;

public class WorkOrderQueryUtil {

	public static final String getWorkOrderList = null;
	public static final String INSERT_WORKORDER_MASTER = null;

}
