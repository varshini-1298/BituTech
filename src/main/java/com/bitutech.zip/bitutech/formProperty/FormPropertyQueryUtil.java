package com.bitutech.formProperty;

public class FormPropertyQueryUtil {

	public static final String getFormPropertyList = "select * from vw_get_user_rigths_forms (?)";
	
}
