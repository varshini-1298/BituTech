package com.bitutech.formProperty;

public interface FormPropertyService {

	FormPropertyResultBean getFormProperty(String userId) throws Exception;
	
	
}
