package com.bitutech.itemproperties;

public class ItemPropertiesBean {
	
	private String unitMeasure;
	private String uomCategory;
	private String description;
	
	public String getUnitMeasure() {
		return unitMeasure;
	}
	public void setUnitMeasure(String unitMeasure) {
		this.unitMeasure = unitMeasure;
	}
	public String getUomCategory() {
		return uomCategory;
	}
	public void setUomCategory(String uomCategory) {
		this.uomCategory = uomCategory;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
	
}
