package com.bitutech.itemproperties;

public class ItemPropertiesQueryUtil {

	public static final String INSERT_ITEM_PROP = "";
	public static final String getItemPropList = "select uom as unitMeasure,uom_category_code as uomCategory,uom_description as description from uom";

}
