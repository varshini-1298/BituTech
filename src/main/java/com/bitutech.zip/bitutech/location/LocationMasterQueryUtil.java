package com.bitutech.location;

public class LocationMasterQueryUtil {

	public static final String getCustomerList = "select form_code as territory,form_name as name,display_order as zipCode,module_code as addressOfCus,is_parent as organisationName from auth.form";
	public static final String INSERT_LOCATION_MASTER = null;

}
