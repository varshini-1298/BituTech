package com.bitutech.stockVerification;

public class StockVerificationBean {
	
	private String stockVerificationNo;
	private String location;
	private String organizationName;
	
	
	public String getStockVerificationNo() {
		return stockVerificationNo;
	}
	public void setStockVerificationNo(String stockVerificationNo) {
		this.stockVerificationNo = stockVerificationNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	

}
